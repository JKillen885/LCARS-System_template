<script setup lang="ts">
import { computed } from 'vue'
import { haState } from '../HAState'
import LCARSTable from './LCARSTable.vue'

const { entity, animation } = defineProps<{
  entity?: string
  animation?: string
}>()

const rows = computed(() => {
  if (!haState?.value?.states || !entity) {
    return
  }
  const rowList: Array<{ key: string; value: string }> = []
  const entityObject = haState?.value?.states[entity]

  if (entityObject) {
    Object.entries((entityObject as any)?.attributes).forEach(([key, value]) => {
      rowList.push({ key, value: value as string })
    })
  }
  return rowList
})
</script>

<template>
  <LCARSTable :animation="animation" v-bind="$attrs">
    <tr v-for="(row, index) in rows" :key="index">
      <td>{{ row.key.replace(/_/g, ' ') }}: {{ row.value }}</td>
    </tr>
  </LCARSTable>
</template>
