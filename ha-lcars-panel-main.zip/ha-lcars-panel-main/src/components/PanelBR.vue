<script setup lang="ts">
import type { MarginProps } from '@/props/MarginProps'
import LCARSCol from './LCARSCol.vue'
import LCARSElement from './LCARSElement.vue'
import LCARSRow from './LCARSRow.vue'

interface PanelBRProps extends MarginProps {
  title?: string
  color?: string | number
  fillWidth?: boolean
  fillHeight?: boolean
  fillRightTop?: boolean
  fillRightBottom?: boolean
  fillBottomLeft?: boolean
  fillBottomRight?: boolean
  gap?: number
  rightWidth?: number
  rightPad?: number
  rightColor?: string | number
  rightGap?: number
  rightStretch?: boolean
  bottomCap?: boolean
  bottomHeight?: number
  bottomGap?: number
  bottomStretch?: boolean
  topCap?: boolean
  outerRadX?: number
  outerRadY?: number
  innerRadX?: number
  innerRadY?: number
  backgroundScale?: number
}

const {
  title,
  color = 'default',
  fillWidth = true,
  fillHeight = true,
  fillRightTop,
  fillRightBottom = true,
  fillBottomLeft,
  fillBottomRight = true,
  gap = 1,
  rightWidth = 3,
  rightPad = 1,
  rightColor,
  rightGap,
  rightStretch,
  bottomHeight = 1,
  bottomCap,
  bottomStretch,
  outerRadX = 2,
  outerRadY = 2,
  innerRadX = 1,
  innerRadY = 1,
  marginTop,
  marginBottom,
  marginLeft,
  marginRight,
  backgroundScale = 100,
} = defineProps<PanelBRProps>()

defineOptions({
  inheritAttrs: false,
})
</script>

<template>
  <LCARSRow
    :margin-top="marginTop"
    :margin-left="marginLeft"
    :margin-right="marginRight"
    :stretch="fillRightTop || fillRightBottom || fillHeight"
  >
    <LCARSCol :fill="fillWidth" :margin-right="rightPad">
      <slot></slot>
    </LCARSCol>
    <LCARSCol :stretch="fillRightTop || fillRightBottom || fillHeight">
      <LCARSElement
        v-if="topCap"
        :cap-top="true"
        :width="rightWidth"
        :height="rightWidth / 2"
        :color="rightColor ?? color"
      ></LCARSElement>
      <LCARSElement
        v-if="fillRightTop"
        :fill="true"
        :color="rightColor ?? color"
        :width="rightWidth"
      ></LCARSElement>
      <LCARSCol
        v-if="$slots.right"
        :stretch="rightStretch || fillRightTop || fillRightBottom || fillHeight"
        :margin-top="(rightGap || gap || 0) / 10"
        :margin-bottom="(rightGap || gap || 0) / 10"
      >
        <slot name="right"></slot>
      </LCARSCol>
      <LCARSElement
        v-if="fillRightBottom"
        :fill="true"
        :color="rightColor ?? color"
        :width="rightWidth"
      ></LCARSElement>
    </LCARSCol>
  </LCARSRow>
  <LCARSRow
    bottom
    :stretch="bottomStretch"
    :margin-left="marginLeft"
    :margin-right="marginRight"
    :margin-bottom="marginBottom"
  >
    <LCARSRow
      :height="bottomHeight"
      :fill="fillBottomLeft || fillBottomRight || fillWidth"
      :stretch="bottomStretch || fillBottomLeft || fillBottomRight || fillWidth"
    >
      <LCARSElement
        v-if="bottomCap"
        :height="bottomHeight"
        :width="bottomHeight / 2"
        :color="color"
        :cap-left="true"
      ></LCARSElement>
      <LCARSElement
        v-if="title"
        :textColor="color"
        :fontSize="bottomHeight"
        :lineHeight="bottomHeight * 0.8"
      >
        {{ title }}
      </LCARSElement>
      <LCARSElement
        v-if="fillBottomLeft"
        :fill="true"
        :color="color"
        :height="bottomHeight"
      ></LCARSElement>
      <slot name="bottom"></slot>
      <LCARSElement
        v-if="fillBottomRight"
        :fill="true"
        :color="color"
        :height="bottomHeight"
      ></LCARSElement>
    </LCARSRow>
    <LCARSElement
      :rad-x-bottom-right="outerRadX"
      :rad-y-bottom-right="outerRadY"
      :rad-x-inner-bottom-right="innerRadX"
      :rad-y-inner-bottom-right="innerRadY"
      :color="color"
      :width="rightWidth + innerRadX"
      :height="bottomHeight + innerRadY"
      :backgroundScale="backgroundScale"
    ></LCARSElement>
  </LCARSRow>
</template>

<style lang="sass">
@use '@/styles/main'
</style>
