import type { MarginProps } from '@/props/MarginProps'
import type { PadProps } from '@/props/PadProps'
import type { RadiusProps } from './RadiusProps'
import type { TapActionProps } from './TapActionProps'

export interface ElementProps extends MarginProps, PadProps, RadiusProps {
  nav?: string
  rootPath?: string
  color?: string | number
  textColor?: string | number
  fontSize?: number
  lineHeight?: number
  positioning?: string
  top?: number | string
  left?: number | string
  width?: number | string
  height?: number | string
  fill?: boolean
  fillWidth?: boolean
  fillHeight?: boolean
  button?: boolean
  alignContent?: string
  textTransform?: string
  tapAction?: TapActionProps
}
